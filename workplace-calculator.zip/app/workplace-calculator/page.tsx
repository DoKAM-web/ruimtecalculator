"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { motion } from "framer-motion"
import { FiHome, FiSettings, FiClipboard, FiGrid, FiArchive } from "react-icons/fi"

export default function WorkstationCalculator() {
  const [values, setValues] = useState({
    A: "",
    D: 0.2,
    E: "",
    F: "",
    H: "", // Oppervlakte in m² ingenomen door machines
    G: 0.2,
    B: 1.075,
    C: 2, // Zitruimte per werkplek volgens NEN 1824-norm
  })
  const [step, setStep] = useState(1)

  const updateValue = (key: string, value: string) => {
    setValues((prevValues) => ({
      ...prevValues,
      [key]: Number.parseFloat(value) || "",
    }))
  }

  const gangpaden = values.A ? Number.parseFloat(values.A as string) * (values.D as number) : 0
  const werkruimteZonderFoutmarge = values.A
    ? Number.parseFloat(values.A as string) -
      (gangpaden +
        (Number.parseFloat(values.E as string) || 0) +
        (Number.parseFloat(values.F as string) || 0) +
        (Number.parseFloat(values.H as string) || 0))
    : 0
  const werkruimteMetFoutmarge = werkruimteZonderFoutmarge ? werkruimteZonderFoutmarge * (1 - (values.G as number)) : 0
  const ruimtePerWerkplek = (values.B as number) + (values.C as number)
  const aantalWerkplekken =
    werkruimteMetFoutmarge && ruimtePerWerkplek ? Math.floor(werkruimteMetFoutmarge / ruimtePerWerkplek) : 0

  return (
    <div className="flex flex-col items-center p-10 space-y-6 bg-gray-100 min-h-screen">
      <motion.h1 className="text-3xl font-bold text-gray-800 flex items-center" animate={{ scale: 1.1 }}>
        <FiGrid className="mr-2 text-blue-600" /> Interactieve Werkplekken Calculator
      </motion.h1>
      <Card className="w-full max-w-lg p-6 shadow-lg rounded-lg bg-white">
        <CardContent>
          {step === 1 && (
            <motion.div animate={{ opacity: 1 }} initial={{ opacity: 0 }}>
              <h2 className="text-xl font-semibold text-gray-700 flex items-center">
                <FiHome className="mr-2 text-blue-600" /> Stap 1: Vul de basisgegevens in
              </h2>
              <label className="block mt-4 text-gray-600">Totale ruimte (m²)</label>
              <Input
                type="number"
                value={values.A as string}
                onChange={(e) => updateValue("A", e.target.value)}
                placeholder="Voer totale ruimte in"
                className="mt-2"
              />
              <label className="block mt-4 text-gray-600">
                Gangpaden percentage <em>(advies: 20%)</em>
              </label>
              <Input
                type="number"
                step="0.01"
                value={values.D as number}
                onChange={(e) => updateValue("D", e.target.value)}
                className="mt-2"
              />
              <label className="block mt-4 text-gray-600">
                Foutmarge <em>(advies: 0,2 (20%))</em>
              </label>
              <Input
                type="number"
                step="0.01"
                value={values.G as number}
                onChange={(e) => updateValue("G", e.target.value)}
                className="mt-2"
              />
              <Button className="mt-6 w-full bg-blue-600 text-white" onClick={() => setStep(2)}>
                Volgende
              </Button>
            </motion.div>
          )}
          {step === 2 && (
            <motion.div animate={{ opacity: 1 }} initial={{ opacity: 0 }}>
              <h2 className="text-xl font-semibold text-gray-700 flex items-center">
                <FiArchive className="mr-2 text-green-600" /> Stap 2: Overige Ruimtes
              </h2>
              <label className="block mt-4 text-gray-600">Werkvoorraadruimte (m²)</label>
              <Input
                type="number"
                value={values.E as string}
                onChange={(e) => updateValue("E", e.target.value)}
                className="mt-2"
              />
              <label className="block mt-4 text-gray-600">Productlocatieruimte (m²)</label>
              <Input
                type="number"
                value={values.F as string}
                onChange={(e) => updateValue("F", e.target.value)}
                className="mt-2"
              />
              <label className="block mt-4 text-gray-600">Oppervlakte ingenomen door machines (m²)</label>
              <Input
                type="number"
                value={values.H as string}
                onChange={(e) => updateValue("H", e.target.value)}
                className="mt-2"
              />
              <Button className="mt-6 w-full bg-blue-600 text-white" onClick={() => setStep(3)}>
                Volgende
              </Button>
            </motion.div>
          )}
          {step === 3 && (
            <motion.div animate={{ opacity: 1 }} initial={{ opacity: 0 }}>
              <h2 className="text-xl font-semibold text-gray-700 flex items-center">
                <FiSettings className="mr-2 text-yellow-600" /> Stap 3: Werkplekken Berekenen
              </h2>
              <label className="block mt-4 text-gray-600">Oppervlakte per werktafel (m²)</label>
              <Input
                type="number"
                value={values.B as number}
                onChange={(e) => updateValue("B", e.target.value)}
                className="mt-2"
              />
              <label className="block mt-4 text-gray-600">
                Zitruimte per werkplek <strong>(Conform NEN 1824: 2 m²)</strong>
              </label>
              <Input
                type="number"
                value={values.C as number}
                onChange={(e) => updateValue("C", e.target.value)}
                className="mt-2"
              />
              <Button className="mt-6 w-full bg-blue-600 text-white" onClick={() => setStep(4)}>
                Berekenen
              </Button>
            </motion.div>
          )}
          {step === 4 && (
            <motion.div animate={{ opacity: 1 }} initial={{ opacity: 0 }}>
              <h2 className="text-xl font-semibold text-gray-700 flex items-center">
                <FiClipboard className="mr-2 text-red-600" /> Resultaat
              </h2>
              <p className="mt-4 text-gray-600">Ruimte per werkplek: {ruimtePerWerkplek.toFixed(2)} m²</p>
              <p className="mt-2 text-gray-600">
                <strong>Totaal aantal werkplekken: {aantalWerkplekken}</strong>
              </p>
              <Button className="mt-6 w-full bg-blue-600 text-white" onClick={() => setStep(1)}>
                Opnieuw
              </Button>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

